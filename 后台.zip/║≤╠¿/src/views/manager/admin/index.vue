
<template>
<d2-container>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    style="width: 100%">
    <!-- //渲染用户模块 -->
          <el-table-column label="id" prop="id">
          </el-table-column>
          <el-table-column label="管理员账号" prop="username">
          </el-table-column>
          <el-table-column label="密码" prop="password">******
          </el-table-column>
          <el-table-column label="权限id" prop="powerid" >
          </el-table-column>
          <el-table-column label="权限" prop="powerName">
          </el-table-column>
          <el-table-column label="状态" prop="status" :formatter="palybakeformt">
          </el-table-column>
    <el-table-column align="right">
      <template slot="header" slot-scope="scope">
        <el-button  @click="Project(scope.$index, scope.row) , dialogFormVisible3 = true">增加</el-button>
      </template>
      <el-dialog title="添加用户" :visible.sync="dialogFormVisible3" append-to-body>
          <el-form :model="tableData" :rules="rules" ref="add" label-width="100px">
          <el-form-item label="账号" prop="username">
              <el-input v-model="add.username" ></el-input>
          </el-form-item>
           <el-form-item label="密码" prop="password">
              <el-input v-model="add.password"></el-input>
          </el-form-item>
          <el-form-item label="权限">
              <el-select v-model="add.powerid" placeholder="请选择权限">
                <el-option label="普通管理员" value="2">普通管理员</el-option>
                <el-option label="教导管理员" value="3">教导管理员</el-option>
              </el-select>
          </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible3 = false">取 消</el-button>
            <el-button type="primary" @click="handleAdd()">确 定</el-button>
          </div>
        </el-dialog>
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="window(scope.$index, scope.row) , dialogFormVisible = true">修改</el-button>
          <el-dialog title="修改信息" :visible.sync="dialogFormVisible" append-to-body>
          <el-form  :model="tableData" :rules="rules" ref="form" label-width="100px">
              <el-form-item label="id" prop="id">
                <el-input v-model="data.id" :disabled="true"></el-input>
              </el-form-item>
          <el-form-item label="姓名" prop="username">
              <el-input v-model="data.username" :disabled="true"></el-input>
          </el-form-item>
           <el-form-item label="密码" prop="password">
              <el-input v-model="data.password"></el-input>
          </el-form-item>
          <el-form-item label="权限">
              <el-select v-model="data.powerid" placeholder="请选择修改的权限">
                <el-option label="超级管理员1" value="1">超级管理员1</el-option>
                <el-option label="普通管理员" value="2">普通管理员</el-option>
                <el-option label="教导管理员" value="3">教导管理员</el-option>
              </el-select>
          </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="close()">取 消</el-button>
            <el-button type="primary" @click="handleEdit(scope.$index , scope.row)">确 定</el-button>
          </div>
        </el-dialog>
        <el-button
          size="mini"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)">处理</el-button>
      </template>
    </el-table-column>
  </el-table>
  </d2-container>
</template>
<script>
import Axios from 'axios'
import util from '@/libs/util'
export default {
  data () {
    return {
      select: '',
      search: '',
      tableData: [],
      dialogFormVisible: false,
      dialogFormVisible3: false,
      data: {
        id: '',
        username: '',
        password: '',
        powerid: ''
      },
      add: {
        username: '',
        password: '',
        powerid: ''
      }
    }
  },

  methods: {
    Project (index, row) {
      // this.data.id = row.id
      // this.data.username = row.username
      // this.data.password = row.password
      // this.data.powerid = row.powerid
      alert('进来了')
    },
    handleAdd (index, row) {
      alert('进入添加函数')
      console.log(this.add)

      Axios.post('http://localhost/admin/Admin', this.add, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        console.log('res数据响应')
        console.log(res)
        if (res.data.code === 200) {
          this.$message('添加成功')
          location.reload()
          this.dialogFormVisible3 = false
        }
      })
    },
    window (index, row) {
      this.data.id = row.id
      this.data.username = row.username
      this.data.password = row.password
      this.data.powerid = row.powerid
    },
    handleEdit (index, row) {
      Axios.put('http://localhost/admin/Admin', this.data, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message('修改成功')
            this.close()
            location.reload()
          } else {
            this.$message('修改失败')
            location.reload()
          }
        })
    },
    handleDelete (index, row) {
      console.log('进入删除函数')
      Axios.delete('http://localhost/admin/Admin', {
        data: {
          id: row.id
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message('删除成功')
            location.reload()
          } else {
            this.$message('删除失败')
          }
        })
    },
    close () {
      this.dialogFormVisible = false
    },
    // 管理员渲染
    render () {
      Axios.get('http://localhost/admin/Admin', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          // const data = res.data.data
          // console.log(data)
          res.data.data.forEach(element => {
            this.tableData.push(element)
          })
        })
    },
    palybakeformt (row, column) {
      if (row.status === 0) {
        return '未启用'
      } else {
        return '已启用'
      }
    }
  },
  mounted () {
    this.render()
    this.state()
  }
}
</script>
