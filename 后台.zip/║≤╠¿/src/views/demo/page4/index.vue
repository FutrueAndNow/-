<template>
<d2-container>
  <div style=" float:right;">
                    <el-input v-model="select" placeholder="输入关键字搜索" style="width: 200px" />
                    <el-button type="primary" @click="serch()">搜索</el-button>
                </div>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    style="width: 100%">
          <el-table-column label="学生工号" prop="id">
          </el-table-column>
          <el-table-column label="学生姓名" prop="stuname">
          </el-table-column>
          <el-table-column label="申请状态" :formatter="playbackFormat" prop="leave_status">
          </el-table-column>
          <el-table-column label="返校说明" prop="remark">
          </el-table-column>
          <el-table-column label="返校时间" prop="return_date">
          </el-table-column>
          <el-table-column
      align="right">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="vend(scope.$index, scope.row),dialogFormVisible1 = true" v-model="data.leave_status">修改</el-button>
          <el-dialog title="修改信息" :visible.sync="dialogFormVisible1" append-to-body>
            <el-form ref="form" :model="form" label-width="180px">
            <el-form-item label="id" prop="id">
              <el-input v-model="data.id" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="学生姓名" prop="stuname">
              <el-input v-model="data.stuname" :disabled="true"></el-input>
            </el-form-item>

             <el-form-item label="状态">
              <el-select v-model="data.leave_status" placeholder="请选择活动区域">
                <el-option label="同意" value="1">同意</el-option>
                <el-option label="拒绝" value="2">拒绝</el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="说明" prop="explain">
              <el-input v-model="data.explain"></el-input>
            </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible1 = false">取 消</el-button>
                <el-button type="primary" @click="handleEdit(scope.$index, scope.row)">确 定</el-button>
            </div>
          </el-dialog>
      </template>
    </el-table-column>
  </el-table>
  </d2-container>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'
// import search from '@/layout/header-aside/mixins/search'
export default {
  data () {
    return {
      select: '',
      data: {
        id: '',
        name: '',
        leave_status: '',
        is_disease: '',
        explain: ''

      },
      state: 1,
      dialogFormVisible1: false,
      tableData: [],
      search: '',
      mini: ''
    }
  },
  methods: {
    serch (index, row) {
      Axios.get('http://localhost/admin/Returnschool', {
        params: {
          stuname: this.select
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        if (res.data.code === 200) {
          this.tableData = res.data.data.data
        }
      })
    },
    vend (_index, row) {
      console.log(row)
      console.log('进入window函数')
      console.log(this.data.leave_status)
      this.data.id = row.id
      this.data.stuname = row.stuname
      this.data.leave_status = row.leave_status
      this.data.explain = row.explain
    },

    // 学生信息修改模块
    handleEdit (index, row) {
      console.log(row)
      console.log('数据相应')
      Axios.put('http://localhost/admin/Returnschool/' + this.data.id, this.data, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          location.reload()
        })
    },
    handleDelete (index, row) {
      console.log(index, row)
    },

    render () {
      Axios.get('http://localhost/admin/Returnschool', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.data.forEach(element => {
            this.tableData.push(element)
          })
          console.log(this.tableData)
        })
    },

    // 文本交互（0，1，2）=>(申请中，同意，拒绝)
    playbackFormat (row, cloumn) {
      if (row.leave_status === 0) {
        return '申请中'
      } else if (row.leave_status === 1) {
        return '同意'
      } else {
        return '拒绝'
      }
    }

  },
  mounted () {
    this.render()
  }

}
</script>
