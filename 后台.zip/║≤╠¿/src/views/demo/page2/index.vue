<template>
<d2-container>
   <div style=" float:right;">
                    <el-input v-model="select" placeholder="输入关键字搜索" style="width: 200px" />
                    <el-button type="primary" @click="serch()">搜索</el-button>
                </div>
  <el-table
    :data="tableData"
    style="width: 100%"
    height="850">
    <!-- 学生个人行程渲染模块 -->
            <el-table-column label="id" prop="id">
            </el-table-column>
            <el-table-column label="学工号" prop="uid">
            </el-table-column>
            <el-table-column label="学生姓名" prop="stuname">
            </el-table-column>
            <el-table-column label="体温" prop="temperature">
            </el-table-column>
            <el-table-column label="状态 " prop="from_address" :formatter="palybakeformt">
            </el-table-column>
            <el-table-column label="详细所在地" prop="address">
            </el-table-column>
            <el-table-column label="当前症状" prop="symptom">
            </el-table-column>
            <el-table-column label="确诊或疑似病例" prop="is_disease">
            </el-table-column>
            <el-table-column label="新冠就诊使" prop="is_covid">
            </el-table-column>
            <el-table-column label="14天内去过中高风险地区" prop="is_higharea" :formatter="palybakeformt2">
            </el-table-column>
            <el-table-column label="14天内是否接触确诊或疑似病历" prop="is_touch" :formatter="palybakeformt3">
            </el-table-column>
            <el-table-column label="健康码" prop="">
            <template slot-scope="scope" >
            <el-image style="width:50px height: 50px;" :src="scope.row.health_code" :preview-src-list="[scope.row.health_code]"/>
            </template>
            </el-table-column>
            <el-table-column label="行程码" prop="trip_code">
               <template slot-scope="scope" >
            <el-image style="width:50px height: 50px;" :src="scope.row.trip_code" :preview-src-list="[scope.row.trip_code]"/>
            </template>
            </el-table-column>
            <!-- 修改弹窗模块 -->
    <el-table-column
      fixed="right"
      label="操作"
      width="100">
      <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.$index, scope.row),dialogFormVisible1 = true">修改</el-button>
           <el-dialog title="修改数据" :visible.sync="dialogFormVisible1" append-to-body="true">
                                        <el-form ref="form" :model="form" label-width="180px">
                                          <el-form-item label="id">
                                            <el-input v-model="data.id" disabled="trun" ></el-input>
                                           </el-form-item>
                                           <el-form-item label="学工号" disabled="trun">
                                            <el-input v-model="data.uid" ></el-input>
                                           </el-form-item>
                                           <el-form-item label="姓名">
                                            <el-input v-model="data.stuname"  disabled="trun"></el-input>
                                           </el-form-item>
                                           <el-form-item label="体温">
                                            <el-input v-model="data.temperature" ></el-input>
                                           </el-form-item>
                                           <el-form-item label="当前所在地"   >
                                             <el-select v-model="data.from_address"  placeholder="请选择活动区域">
                                               <el-option label="外出" value="3" ></el-option>
                                              <el-option label="在家" value="2" ></el-option>
                                               <el-option label="在校" value="1"></el-option>
                                             </el-select>
                                           </el-form-item>
                                           <el-form-item label="详细所在地">
                                               <el-input v-model="data.address" >   </el-input>
                                              </el-form-item>
                                              <el-form-item label="当前症状">
                                               <el-input v-model="data.symptom" >   </el-input>
                                              </el-form-item>
                                              <el-form-item label="确诊或疑似病例">
                                                <el-select v-model="data.is_disease"  placeholder="请选择活动区域">
                                               <el-option label="无" value="0" ></el-option>
                                              <el-option label="确诊" value="1" ></el-option>
                                               <el-option label="疑似" value="2"></el-option>
                                             </el-select>
                                              </el-form-item>
                                               <el-form-item label="新冠就诊使">
                                               <el-input v-model="data.is_covid" >   </el-input>
                                              </el-form-item>
                                          </el-form>
                            <div slot="footer" class="dialog-footer">
                                <el-button @click="dialogFormVisible1 = false">取 消</el-button>
                                <el-button type="primary" @click="bbt(scope.$index, scope.row)">确 定</el-button>
                            </div>
                        </el-dialog>
      </template>
    </el-table-column>
  </el-table>
  </d2-container>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'
export default {
  data () {
    return {
      select: '',
      data: {
        id: '',
        uid: '',
        address: '',
        stuname: '',
        temperature: '',
        from_address: '',
        symptom: '',
        is_higharea: '',
        is_touch: '',
        is_disease: '',
        is_covid: ''

      },
      dialogFormVisible1: false,
      tableData: [],
      search: '',
      mini: ''
    }
  },
  methods: {
    serch (index, row) {
      Axios.get('http://localhost/admin/Tripreport', {
        params: {
          stuname: this.select
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        if (res.data.code === 200) {
          this.tableData = res.data.data.data
        }
      })
    },
    // 窗口数据初始化
    handleEdit (index, row) {
      this.data.id = row.id
      this.data.uid = row.uid
      this.data.stuname = row.stuname
      this.data.temperature = row.temperature
      this.data.from_address = row.from_address
      this.data.address = row.address
      this.data.symptom = row.symptom
      this.data.is_disease = row.is_disease
      this.data.is_covid = row.is_covid
    },
    // 修改数据方法
    bbt () {
      Axios.put('http://localhost/admin/Tripreport/' + this.data.id, this.data, {
        headers:
        {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message({
              type: 'success',
              message: '修改成功'
            })
            location.reload()
          } else {
            this.$message({
              type: 'error',
              message: res.data.message
            })
          }
        })
        // .catch((err) => {
        //   console.log(res.message)
        // })
    },
    // 数据渲染方法·
    render () {
      console.log(5456456456)
      Axios.get('http://localhost/admin/Tripreport', {
        headers:
        {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.data.forEach(element => {
            this.tableData.push(element)
          })
          console.log(this.tableData)
        })
        .catch((res) => {
          console.log(res.$message)
        })
    },
    // 1、住校 2、居家 3、外出
    palybakeformt (row, column) {
      if (row.from_address === 1) {
        return '在校'
      } else if (row.from_address === 2) {
        return '居家'
      } else {
        return '外出'
      }
    },
    // 1、是 2、否
    palybakeformt2 (row, column) {
      if (row.is_higharea === 1) {
        return '是'
      } else {
        return '否'
      }
    },
    palybakeformt3 (row, column) {
      if (row.is_touch === 1) {
        return '是'
      } else {
        return '否'
      }
    }
  },
  // <!-- 0、无 1、确诊 2、疑似 -->
  palybakeformt2 (row, column) {
    if (row.is_disease === 0) {
      return '无'
    } else if (row.is_disease === 1) {
      return '确诊'
    } else {
      return '疑似'
    }
  },
  mounted () {
    this.render()
  }
}
</script>
<style>
.el-image__error, .el-image__inner, .el-image__placeholder {
    width: 50%;
    height: 50%;
}
</style>
