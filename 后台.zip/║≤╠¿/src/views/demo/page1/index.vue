<template>
<d2-container>
   <div style=" float:right;">
                    <el-input v-model="select" placeholder="输入关键字搜索" style="width: 200px" />
                    <el-button type="primary" @click="serch()">搜索</el-button>
                </div>
  <el-table :data="tableData" style="width: 100%"
  height="600">
  <!-- 渲染学生基本数据 -->
    <el-table-column label="id" prop="id">
    </el-table-column>
    <el-table-column label="姓名" prop="name">
    </el-table-column>
    <el-table-column label="学工号" prop="uid">
    </el-table-column>
    <el-table-column label="密码" prop="password">
      ******
    </el-table-column>
    <el-table-column label="在校状态" prop="in_school_status" :formatter="palybakeformt">
    </el-table-column>
<!-- 添加功能弹窗模块 -->
    <el-table-column align="right">
      <template slot-scope="scope">
        <el-button size="mini" @click="vend(scope.$index, scope.row), dialogFormVisible = true" v-model="data.in_school_status">修改</el-button>
        <el-dialog title="修改信息" :visible.sync="dialogFormVisible" append-to-body>
          <el-form  :model="tableData" :rules="rules" ref="form" label-width="100px">
            <el-form-item label="id" prop="id">
              <el-input v-model="data.id" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="学工号" prop="uid">
              <el-input v-model="data.uid" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="姓名" prop="name">
              <el-input v-model="data.name" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="password">
              <el-input v-model="data.password" show-password></el-input>
            </el-form-item>
            <el-form-item label="状态">
              <el-select v-model="data.in_school_status" placeholder="请选择活动区域">
                <el-option label="离校0" value="0">离校0</el-option>
                <el-option label="在校1" value="1">在校1</el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="handleEdit(scope.$index, scope.row)">确 定</el-button>
          </div>
        </el-dialog>
      </template>
    </el-table-column>
  </el-table>
  </d2-container>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'
export default {
  data () {
    return {
      select: '',
      tableData: [],
      dialogFormVisible: false,
      data:
      {
        id: '',
        uid: '',
        name: '',
        password: '',
        in_school_status: ''
      }
    }
  },
  methods: {
    //  查询信息
    serch (index, row) {
      Axios.get('http://localhost/admin/Student', {
        params: {
          name: this.select
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        if (res.data.code === 200) {
          this.tableData = res.data.data.data
        }
      })
    },
    // 弹窗数据初始化
    vend (_index, row) {
      console.log(row)
      console.log('进入window函数')
      console.log(this.data.in_school_status)
      this.data.id = row.id
      this.data.uid = row.uid
      this.data.name = row.name
      this.data.in_school_status = row.in_school_status
      this.data.password = row.password
    },
    // 学生信息修改模块
    handleEdit (index, row) {
      console.log(row)
      console.log('数据相应')
      Axios.put('http://localhost/admin/Student/' + this.data.id, this.data, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          if (res.data.code === 200) {
            this.$message('修改成功')
            location.reload()
            this.dialogFormVisible = false
          }
        })
    },
    handleDelete (index, row) {
      console.log(index, row)
    },
    //  学生数据渲染方法
    render () {
      Axios.get('http://localhost/admin/Student', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          res.data.data.data.forEach(element => {
            this.tableData.push(element)
          })
        })
    },
    palybakeformt (row, column) {
      if (row.in_school_status === 0) {
        return '离校'
      } else {
        return '在校'
      }
    }
  },
  mounted () {
    this.render()
  }
}
</script>
