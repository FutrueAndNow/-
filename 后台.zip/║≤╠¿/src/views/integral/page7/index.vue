<template>
<d2-container>
   <div style=" float:right;">
                    <el-input v-model="select" placeholder="输入关键字搜索" style="width: 200px" />
                    <el-button type="primary" @click="serch()">搜索</el-button>
                </div>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    style="width: 100%">
    <el-table-column
      label="id"
      prop="id">
    </el-table-column>
    <el-table-column
      label="学生姓名"
      prop="stuname">
    </el-table-column>
    <el-table-column
      label="积分值"
      prop="point">
    </el-table-column>
    <el-table-column
      label="签到天数"
      prop="days">
    </el-table-column>
    <el-table-column
      align="right">
       <template slot-scope="scope">
        <el-button size="mini" @click="window(scope.$index, scope.row), dialogFormVisible = true" v-model="data.in_school_status">修改</el-button>
        <el-dialog title="修改信息" :visible.sync="dialogFormVisible" append-to-body>
          <el-form  :model="tableData" :rules="rules" ref="form" label-width="100px">
            <el-form-item label="id" prop="id">
              <el-input v-model="data.id" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="学工号" prop="uid">
              <el-input v-model="data.uid" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="姓名" prop="sname">
              <el-input v-model="data.stuname" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="签到天数" prop="days">
              <el-input v-model="data.days" ></el-input>
            </el-form-item>
            <el-form-item label="积分值">
              <el-input v-model="data.point"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="closein">取 消</el-button>
            <el-button type="primary" @click="handleEdit(scope.$index, scope.row)">确 定</el-button>
          </div>
        </el-dialog>
      </template>
    </el-table-column>
  </el-table>
  </d2-container>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'
export default {
  data () {
    return {
      select: '',
      tableData: [],
      dialogFormVisible: false,
      data: {
        id: '',
        uid: '',
        days: '',
        stuname: '',
        point: ''
      }

    }
  },
  methods: {
    serch (index, row) {
      Axios.get('http://localhost/admin/Points', {
        params: {
          stuname: this.select
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        if (res.data.code === 200) {
          this.tableData = res.data.data.data
        }
      })
    },
    closein () {
      this.dialogFormVisible = false
    },
    window (index, row) {
      this.data.id = row.id
      this.data.uid = row.uid
      this.data.stuname = row.stuname
      this.data.point = row.point
      this.data.days = row.days
    },
    handleEdit (index, row) {
      Axios.put('http://localhost/admin/Points/' + this.data.id, this.data, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            alert('修改成功')
            this.closein()
            location.reload()
          }
        })
    },
    handleDelete (index, row) {
      console.log(index, row)
    },

    render () {
      Axios.get('http://localhost/admin/Points', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.data.forEach(element => {
            this.tableData.push(element)
          })
          console.log(this.tableData)
        })
    }

  },
  mounted () {
    this.render()
  }

}
</script>
