<template>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    style="width: 100%">
    <el-table-column
      label="id"
      prop="id">
    </el-table-column>
    <el-table-column
      label="学生姓名"
      prop="stuname">
    </el-table-column>
    <el-table-column
      label="积分值"
      prop="nowpoint">
    </el-table-column>
    <el-table-column
      label="积分获取情况"
      prop="remark">
    </el-table-column>
    <el-table-column
      align="right">
      <template slot="header" slot-scope="scope">
        <el-button
          size="mini"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)">清空</el-button>
      </template>
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="handleEdit(scope.$index, scope.row)">修改</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'
export default {
  data () {
    return {
      tableData: []

    }
  },
  methods: {
    handleEdit (index, row) {
      console.log('进入修改函数')
    },
    // 删除模块方法
    handleDelete (index, row) {
      console.log('进入删除函数')
      // console.log(index, row)
      this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        Axios.delete('http://localhost/admin/Pointlog', {
          headers: {
            Authorization: util.cookies.get('token')
          }
        }).then((res) => {
          console.log(res)
          if (res.data.code === 200) {
            this.$message.success('删除成功！')
            location.reload()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    render () {
      Axios.get('http://localhost/admin/Pointlog', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.data.forEach(element => {
            this.tableData.push(element)
          })
        })
    }

  },
  mounted () {
    this.render()
  }

}
</script>
