<template>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    style="width: 100%">
    <el-table-column
      label="id"
      prop="id">
    </el-table-column>
    <el-table-column
      label="签到天数"
      prop="check_days">
    </el-table-column>
    <el-table-column
      label="获得积分值"
      prop="point_num">
    </el-table-column>
    <el-table-column
      align="right">
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="window(scope.$index, scope.row), dialogFormVisible=true">修改</el-button>
           <el-dialog title="修改信息" :visible.sync="dialogFormVisible" append-to-body>
          <el-form  :model="tableData" :rules="rules" ref="form" label-width="100px">
            <el-form-item label="id" prop="id">
              <el-input v-model="data.id" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="签到天数" prop="check_days">
              <el-input v-model="data.check_days" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="签到积分值" prop="point_num">
              <el-input v-model="data.point_num"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="handleEdit(scope.$index, scope.row)">确 定</el-button>
          </div>
        </el-dialog>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import Axios from 'axios'
import util from '@/libs/util'
export default {
  data () {
    return {
      tableData: [],
      search: '',
      dialogFormVisible: false,
      data: {
        id: '',
        check_days: '',
        point_num: ''
      }
    }
  },
  methods: {
    window (index, row) {
      this.data.id = row.id
      this.data.check_days = row.check_days
      this.data.point_num = row.point_num
    },
    handleEdit (index, row) {
      console.log(this.data)
      Axios.put('http://localhost/admin/Pointrule', this.data, {
        data: {
          check_days: this.data.check_days,
          point: this.data.point_num
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        console.log(res)
        if (res.data.code === 200) {
          this.$message(res.data.message)
          // location.reload()
          this.dialogFormVisible = false
        } else {
          this.$message(res.data.message)
          // location.reload()
          this.dialogFormVisible = false
        }
      })
    },
    handleDelete (index, row) {
      console.log(index, row)
    },
    render () {
      Axios.get('http://localhost/admin/Pointrule', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.forEach(element => {
            this.tableData.push(element)
          })
        })
    }
  },
  mounted () {
    this.render()
  }
}
</script>
