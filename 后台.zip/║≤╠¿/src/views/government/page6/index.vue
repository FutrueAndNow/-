<template>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    tyle="width: 100%"
    height="750">
    <!-- <input type="text" class="add" @click="add" value="新增"> -->
    <el-table-column
      label="防疫id"
      prop="id">
    </el-table-column>
    <el-table-column
      label="防疫标题"
      prop="title">
    </el-table-column>
    <el-table-column
      label="防疫内容"
      prop="content">
    </el-table-column>
    <el-table-column
      label="防疫文章来源"
      prop="source">
    </el-table-column>
    <el-table-column
      label="防疫文章发布日期"
      prop="create_time">
    </el-table-column>
    <el-table-column
      align="right">
      <template slot="header" slot-scope="scope">
        <template>
            <div>
              <!-- 根据条件查询和添加 -->
                    <el-button
                    size="mini"
                    type="danger"
                    @click="vend(scope.$index,scope.row), dialogFormVisible1 = true">增加</el-button>
                    <el-dialog title="新增信息" :visible.sync="dialogFormVisible1">
                    <el-form :model="form" ref="form" label-width="100px">
                      <el-form-item label="防疫标题" prop="title">
                        <el-input v-model="from.title"></el-input>
                      </el-form-item>
                      <el-form-item label="防疫内容" prop="content">
                        <el-input v-model="from.content"></el-input>
                      </el-form-item>
                      <el-form-item label="防疫文章来源" prop="source">
                        <el-input v-model="from.source"></el-input>
                      </el-form-item>
                      <el-form-item label="发布日期" prop="create_time">
                        <el-input v-model="from.create_time" ></el-input>
                      </el-form-item>
                  </el-form>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="dialogFormVisible1 = false">取消</el-button>
                      <el-button type="primary" @click="handleAdd(scope.$index, scope.row)">确定</el-button>
                    </div>
                    </el-dialog>
            </div>
        </template>
        <template slot="header" slot-scope="">
          <el-input v-model="search" size="mini"
        placeholder="防疫文章搜索"></el-input>
        </template>
      </template>
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="window(scope.$index,scope.row), dialogFormVisible = true">修改</el-button>
          <el-dialog title="修改信息" :visible.sync="dialogFormVisible" append-to-body>
          <el-form :model="form" ref="form" label-width="100px">
            <el-form-item label="防疫id" prop="id">
              <el-input v-model="data.id" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="防疫标题" prop="title">
              <el-input v-model="data.title"></el-input>
            </el-form-item>
            <el-form-item label="防疫文章内容" prop="content">
              <el-input v-model="data.content"></el-input>
            </el-form-item>
            <el-form-item label="防疫文章来源" prop="source">
              <el-input v-model="data.source"></el-input>
            </el-form-item>
            <el-form-item label="防疫文章发布日期" prop="create_time">
              <el-input v-model="data.create_time" ></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取消</el-button>
          <el-button type="primary" @click="handleEdit(scope.$index, scope.row)">确定</el-button>
        </div>
        </el-dialog>
          <el-button
          size="mini"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'

export default {
  inject: ['reload'],
  data () {
    return {
      data:
      {
        id: '',
        title: '',
        content: '',
        source: '',
        create_time: ''
      },
      from: {
        title: '',
        content: '',
        source: '',
        create_time: ''
      },
      state: 1,
      tableData: [],
      search: '',
      show: false,
      dialogFormVisible1: false,
      dialogFormVisible: false,
      mini: ''
    }
  },
  methods: {
    window (index, row) {
      console.log(row)
      console.log('进入window函数')
      this.data.id = row.id
      this.data.title = row.title
      this.data.content = row.content
      this.data.source = row.source
      this.data.create_time = row.create_time
    },
    vend (index, row) {
      console.log(index, row)
      console.log('add闲赢')
    },
    // 新增
    handleAdd (index, row) {
      Axios.post('http://localhost/admin/Epknowledge', this.from, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message('修改成功')
            location.reload()
            this.dialogFormVisible1 = false
          } else {
            this.$message.error('新增失败')
          }
        })
    },
    // 修改
    handleEdit (index, row) {
      console.log(this.data)
      Axios.put('http://localhost/admin/Epknowledge', this.data, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message.success('修改成功')
            location.reload()
            this.dialogFormVisible = false
          } else {
            this.$message.error('修改失败')
          }
        })
    },
    // 删除
    handleDelete (index, row) {
      console.log(index, row)
      Axios.delete('http://localhost/admin/Epknowledge', {
        data: {
          id: row.id
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        if (res.data.code === 200) {
          this.$message.success('删除成功')
          location.reload()
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    // 渲染
    render () {
      Axios.get('http://localhost/admin/Epknowledge', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.forEach(element => {
            this.tableData.push(element)
          })
          console.log(this.tableData)
        })
    }
  },
  mounted () {
    this.render()
  }
}
</script>
