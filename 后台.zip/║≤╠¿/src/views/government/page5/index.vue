<template>
<d2-container>
  <el-table
    :data="tableData.filter(data => !search || data.name.toLowerCase().includes(search.toLowerCase()))"
    tyle="width: 100%"  height="740">
    <!-- <input type="text" class="add" @click="add" value="新增"> -->
          <el-table-column label="政策id" prop="id">
          </el-table-column>
          <el-table-column label="政策标题" prop="title">
          </el-table-column>
          <el-table-column label="政策内容" prop="content">
          </el-table-column>
          <el-table-column label="政策来源" prop="source">
          </el-table-column>
          <el-table-column label="政策发布日期" prop="create_time">
          </el-table-column>
    <el-table-column
      align="right">
      <template slot="header" slot-scope="scope">
        <template>
            <div>
              <!-- 根据条件查询和添加 -->
                    <el-button
                    size="mini"
                    type="danger"
                    @click="vend(scope.$index,scope.row), dialogFormVisible1 = true">增加</el-button>
                    <el-dialog title="新增信息" :visible.sync="dialogFormVisible1">
                    <el-form :model="form" ref="from" label-width="100px">
                      <el-form-item label="政策标题" prop="title">
                        <el-input v-model="from.title"></el-input>
                      </el-form-item>
                      <el-form-item label="政策内容" prop="content">
                        <el-input v-model="from.content"></el-input>
                      </el-form-item>
                      <el-form-item label="政策来源" prop="source">
                        <el-input v-model="from.source"></el-input>
                      </el-form-item>
                      <el-form-item label="政策发布日期" prop="create_time">
                        <el-input v-model="from.create_time" ></el-input>
                      </el-form-item>
                  </el-form>
                    <div slot="footer" class="dialog-footer">
                      <el-button @click="dialogFormVisible1 = false">取消</el-button>
                      <el-button type="primary" @click="handleAdd(scope.$index, scope.row)">确定</el-button>
                    </div>
                    </el-dialog>
            </div>
        </template>
        <template slot="header" slot-scope="">
          <el-input v-model="search" size="mini"
        placeholder="政策搜索"></el-input>
        </template>
      </template>
      <template slot-scope="scope">
        <el-button
          size="mini"
          @click="window(scope.$index,scope.row), dialogFormVisible = true">修改</el-button>
          <el-dialog title="修改信息" :visible.sync="dialogFormVisible" append-to-body>
          <el-form :model="form" ref="form" label-width="100px">
            <el-form-item label="政策id" prop="id">
              <el-input v-model="data.id" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="政策标题" prop="title">
              <el-input v-model="data.title"></el-input>
            </el-form-item>
            <el-form-item label="政策内容" prop="content">
              <el-input v-model="data.content"></el-input>
            </el-form-item>
            <el-form-item label="政策来源" prop="source">
              <el-input v-model="data.source"></el-input>
            </el-form-item>
            <el-form-item label="政策发布日期" prop="create_time">
              <el-input v-model="data.create_time" ></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取消</el-button>
          <el-button type="primary" @click="handleEdit(scope.$index, scope.row)">确定</el-button>
        </div>
        </el-dialog>
          <el-button
          size="mini"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  </d2-container>
</template>

<script>
import util from '@/libs/util'
import Axios from 'axios'
export default {
  inject: ['reload'],
  data () {
    return {
      select: '',
      data:
      {
        id: '',
        title: '',
        content: '',
        source: '',
        create_time: ''
      },
      from: {
        title: '',
        content: '',
        source: '',
        create_time: ''
      },
      state: 1,
      tableData: [],
      search: '',
      show: false,
      dialogFormVisible1: false,
      dialogFormVisible: false,
      mini: ''
    }
  },
  methods: {
    serch (index, row) {
      Axios.get('http://localhost/admin/Govdocument', {
        params: {
          title: this.select
        },
        headers: {
          Authorization: util.cookies.get('token')
        }
      }).then((res) => {
        if (res.data.code === 200) {
          this.tableData = res.data.data.data
        }
      })
    },
    window (index, row) {
      console.log(row)
      console.log('进入window函数')
      this.data.id = row.id
      this.data.title = row.title
      this.data.content = row.content
      this.data.source = row.source
      this.data.create_time = row.create_time
    },
    vend (index, row) {
      console.log(index, row)
      console.log('add响应')
    },
    // 新增
    handleAdd (index, row) {
      console.log(this.data)
      Axios.post('http://localhost/admin/Govdocument', this.from, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message.success('新增成功')
            location.reload()
            this.dialogFormVisible1 = false
          } else {
            this.$message.error('新增失败')
          }
        })
    },
    // 修改
    handleEdit (index, row) {
      console.log(this.data)
      Axios.put('http://localhost/admin/Govdocument', this.data, {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          if (res.data.code === 200) {
            this.$message.success('修改成功')
            location.reload()
            this.dialogFormVisible1 = false
          } else {
            this.$message.error('修改失败')
          }
        })
    },
    // 删除
    handleDelete (index, row) {
      console.log('进入删除函数')
      console.log(index, row)
      Axios.delete('http://localhost/admin/Govdocument', {
        data: {
          id: row.id
        },
        headers: { Authorization: util.cookies.get('token') }
      }).then((res) => {
        console.log(res)
        if (res.data.code === 200) {
          this.$message.success('删除成功')
          location.reload()
          this.dialogFormVisible1 = false
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    // 渲染
    render () {
      Axios.get('http://localhost/admin/Govdocument', {
        headers: {
          Authorization: util.cookies.get('token')
        }
      })
        .then((res) => {
          console.log(res)
          res.data.data.forEach(element => {
            this.tableData.push(element)
          })
          console.log(this.tableData)
        })
    }
  },
  mounted () {
    this.render()
  }
}
</script>
<style>
.el-table__cell .cell{
 height: 100px;
 overflow: auto;
}
.el-table__cell .cell::-webkit-scrollbar {

 height: 0;

 width: 0;

 color: transparent;

}
</style>
