import page from './page'

export default page
