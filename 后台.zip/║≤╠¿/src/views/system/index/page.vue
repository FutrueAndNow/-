<template>

  <div class="hello">
    <div ref="mapbox" style="width: 800px; height: 600px; margin: 0 auto;"></div>
    <!-- 初始化echarts需要有个宽高的盒子 -->
  </div>
</template>

<script>
import echarts from 'echarts'
import 'echarts/map/js/china.js'
import jsonp from 'jsonp'
import axios from 'axios'
const option = {
  title: {
    // 标题内容
    text: '全国疫情图',
    link: 'https://baidu.com',
    subtext: '123456',
    sublink: 'https://baidu.com'
  },
  series: [
    {
      name: '确诊人数',
      type: 'map',
      // 告诉echarts渲染一个地图
      map: 'china',
      // 告诉echarts渲染中国地图
      label: {
        // 设置地区汉字
        show: true,
        color: '#333',
        fontSize: 10
      },
      itemStyle: {
        // 地图区域样式
        areaColor: '#eee'
      },
      roam: true,
      // 鼠标滚轮效果
      zoom: 1.2,
      // 地图放大缩小
      emphasis: {
        // 鼠标经过地图和字体样式
        label: {
          color: '#fff',
          fontSize: 12
        },
        itemStyle: {
          areaColor: '#ccc'
        }
      },
      data: []
      // 展示后台给的数据，必须格式（name:xxx;value:xxx）
    }
  ],
  visualMap: [
    {
      // 区域显示颜色
      type: 'piecewise',
      show: true,
      // splitNumber: 4
      pieces: [
        { min: 10000 },
        { min: 1000, max: 9999 },
        { min: 100, max: 999 },
        { min: 10, max: 99 },
        { min: 1, max: 9 },
        { min: 0, max: 0 }
      ],
      inRange: {
        // 区域图标样式
        symbol: 'rect',
        color: [
          '#FFFFFF',
          '#FFAA85',
          '#FF7B69',
          '#CC2929',
          '#8C0D0D',
          '#660208'
        ]
      }
    }
  ],
  tooltip: {
    // 鼠标放上去显示内容
    trigger: 'item',
    formatter: '{b}:确诊{c}'
  },
  toolbox: {
    // 下载
    show: true,
    orient: 'vertical',
    left: 'right',
    top: 'center',
    feature: {
      dataView: { readyOnly: false },
      restore: {}
    }
  }
}

export default {
  name: 'HelloWorld',
  data () {
    return {

    }
  },
  mounted () {
    this.getData()
    this.mycharts = echarts.init(this.$refs.mapbox)
    // 初始化echarts
    this.mycharts.setOption(option)
  },
  methods: {
    getData () {
      axios
        .get(
          'https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=localCityNCOVDataList,diseaseh5Shelf'
        )
        .then((res) => {
          // console.log(222222222222);
          console.log(res)
          // let name = res.data.data.diseaseh5Shelf.areaTree[0].children.map((item) => ({
          //   name: item.name,
          //   }));
          //   console.log(name)
          // let value = res.data.data.diseaseh5Shelf.areaTree[0].children.map((item) => ({
          //   value: item.today.confirm,
          //   }));
          // let name = res.data.data.diseaseh5Shelf.areaTree[0].children.map((item) => ({
          //   name: item.name,
          //   }));
          console.log(name)
          const list = res.data.data.diseaseh5Shelf.areaTree[0].children.map((item) => ({
            name: item.name,
            value: item.today.confirm
          }))
          // console.log(list)
          // console.log(res.data.data.diseaseh5Shelf.areaTree[0].today);
          option.series[0].data = list
          this.mycharts.setOption(option)
          // echarts初始化的前提是dom渲染完成
        })

      // jsonp(
      //   "https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=localCityNCOVDataList,diseaseh5Shelf",
      //   {},
      //   (err, data) => {
      //     if (!err) {
      //       console.log(data);
      //       let list = data.data.list.map((item) => ({
      //         name: item.name,
      //         value: item.value,
      //       }));
      //       option.series[0].data = list;
      //       this.mycharts.setOption(option);
      //       // echarts初始化的前提是dom渲染完成
      //     }
      //   }
      // );
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1,
h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
