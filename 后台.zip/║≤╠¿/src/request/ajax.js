import util from '@/libs/util'
import axios from 'axios'
const ajax = axios.create({
  // baseURL: 'https://some-domain.com/api/',
  timeout: 2000
  // headers: {'X-Custom-Header': 'foobar'}
})

// 添加请求拦截器
ajax.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  config.header.Authorization = util.cookies.get('token')
  return config
}, function (error) {
  // 对请求错误做些什么
  return Promise.reject(error)
})

export default ajax
