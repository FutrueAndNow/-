import { uniqueId } from 'lodash'

/**
 * @description 给菜单数据补充上 path 字段
 * @description https://github.com/d2-projects/d2-admin/issues/209
 * @param {Array} menu 原始的菜单数据
 */
function supplementPath (menu) {
  return menu.map(e => ({
    ...e,
    path: e.path || uniqueId('d2-menu-empty-'),
    ...e.children ? {
      children: supplementPath(e.children)
    } : {}
  }))
}

export const menuHeader = supplementPath([
  {
    title: '学生数据',
    icon: 'folder-o',
    children: [
      { path: '/index', title: '首页', icon: 'home' },
      { path: '/page1', title: '学生数据信息' },
      { path: '/page2', title: '学生行程报备' },
      { path: '/page3', title: '学生出校申请' },
      { path: '/page4', title: '学生返校申请' },
      { path: '/page5', title: '政府资讯' },
      { path: '/page6', title: '防疫知识' },
      { path: '/page7', title: '学生积分' },
      { path: '/page8', title: '积分日志' },
      { path: '/page9', title: '积分规则' },
      { path: '/manager', title: '管理' }

    ]
  }
])
// const children = [
//   { path: '/index', title: '首页', icon: 'home' },
//   { path: '/page1', title: '学生数据信息' },
//   { path: '/page2', title: '学生行程报备' },
//   { path: '/page3', title: '学生出校申请' },
//   { path: '/page4', title: '学生返校申请' },
//   { path: '/page5', title: '政府资讯' },
//   { path: '/page6', title: '防疫知识' },
//   { path: '/page7', title: '学生积分' },
//   { path: '/page8', title: '积分日志' },
//   { path: '/page9', title: '积分规则' },
//   { path: '/manager', title: '管理' }

// ]
// export const menuAside = supplementPath(children)
export const menuAside = supplementPath([
  { path: '/index', title: '首页', icon: 'home' },
  {
    title: '学生管理',
    icon: 'folder-o',
    children: [
      { path: '/page1', title: '学生数据信息' },
      { path: '/page2', title: '学生行程报备' },
      { path: '/page3', title: '学生出校申请' },
      { path: '/page4', title: '学生返校申请' }
      // { path: '/page7', title: '学生积分' },
      // { path: '/page8', title: '积分日志' },
      // { path: '/page9', title: '积分规则' },
    ]
  },
  {
    title: '疫情防控',
    icon: 'folder-o',
    children: [
      { path: '/page5', title: '政府资讯' },
      { path: '/page6', title: '防疫知识' },
      { path: '/outing', title: '出校申请记录' },
      { path: '/back', title: '返校申请记录' }

    ]
  },
  {
    title: '积分设置',
    icon: 'folder-o',
    children: [
      { path: '/page7', title: '学生积分' },
      { path: '/page8', title: '积分日志' },
      { path: '/page9', title: '积分规则' }
    ]
  },
  {
    title: '管理',
    icon: 'folder-o',
    children: [
      { path: '/manager', title: '管理' }
    ]

  }

])
// const a = util.cookies.get('powerid')
// if (a == 1) {
//   children.push({ path: '/manager', title: '权限管理' })
// }

// export const menuAside = supplementPath(children)
